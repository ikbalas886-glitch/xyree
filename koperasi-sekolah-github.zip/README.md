# KoperasiKu
Aplikasi manajemen koperasi sekolah berbasis React + Vite.

## Fitur
- Dashboard omzet, laba kotor, pengeluaran, dan stok menipis.
- Tambah/edit/hapus produk, kategori, foto produk, harga modal/jual, dan stok.
- Catat penjualan; stok otomatis berkurang.
- Catat pengeluaran beserta kategori, tanggal, dan keterangan.
- Riwayat penjualan, filter tanggal, laporan 7 hari, ekspor CSV.
- Data tersimpan di browser dengan localStorage.

## Jalankan
1. Instal Node.js LTS.
2. Ekstrak ZIP dan buka terminal pada folder ini.
3. Jalankan `npm install` lalu `npm run dev`.

## GitHub Pages
Unggah isi folder proyek ke repository (branch `main`). Buka Settings → Pages, pilih GitHub Actions. Workflow deploy sudah tersedia di `.github/workflows/deploy.yml`.

## Penting
Aplikasi ini fungsional di browser, tetapi penyimpanan masih lokal pada perangkat/browser yang dipakai. Data tidak tersinkron otomatis ke HP lain dan belum ada login/database server. Untuk koperasi dengan banyak petugas, diperlukan backend seperti Supabase. Foto sebaiknya dikompres sebelum diunggah agar penyimpanan browser tidak cepat penuh.
